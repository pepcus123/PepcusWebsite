NOTE: This page is obsolete now - the name is fixed at SVG-edit now.
Possible Names

Put all name ideas here:

    Savage Editor
    Carve: from an [earlier project](http://codedread.com/carve/) by codedread
    SViGgy (the friendly SVG editor)

        (alternative spellings are possible, such as SViiGy, SViiGgy, SViiGee, etc.)

    Wizzy the Vector Wizzard (or Vizzy)
    VectAble VectorAble
    AniVector NodeSVG
    Resizable Graphics
    AllSize Move & Graphic
    Vectigo
    ScalarDraw

Possible Re-versioning

It was also brought up that the current version numbering (2.3) does not really match with what people consider version 1.0 software (there are several things missing from what one would expect of a basic vector graphics editor). If we rename the project it is an opportunity to also rectify this.

What version number would you assign to SVG-edit 2.3 ? Put your thoughts below:

    codedread: I would give SVG-edit 2.3 a version number of 0.8, with the next release (currently 2.4) as 0.9. I think 1.0 would be for when the editor can support a good percentage of SVG found throughout the web and supports all basic manipulation.
