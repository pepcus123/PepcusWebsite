export default {
  name: 'Connector',
  langList: [
    {id: 'mode_connect', title: 'Connect two objects'}
  ],
  buttons: [
    {
      title: 'Connect two objects'
    }
  ]
};
