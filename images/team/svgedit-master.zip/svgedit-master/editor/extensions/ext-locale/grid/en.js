export default {
  name: 'View Grid',
  buttons: [
    {
      title: 'Show/Hide Grid'
    }
  ]
};
