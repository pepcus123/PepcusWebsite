export default {
  name: 'MathJax',
  buttons: [
    {
      title: 'Add Mathematics'
    }
  ]
};
