export default {
  saved: 'Saved! Return to Item View!'
};
