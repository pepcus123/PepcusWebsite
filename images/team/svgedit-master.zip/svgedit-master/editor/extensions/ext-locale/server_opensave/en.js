export default {
  uploading: 'Uploading...'
};
